package com.piseth.java.school;

import java.util.List;

import com.piseth.java.school.model.Student;
import com.piseth.java.school.service.StudentService;
import com.piseth.java.school.service.StudentServiceImpl;

public class InterfaceDemoApp {
/*
 * លំហាត់ April-6
	គេអោយ interface ដែលមាន method :
	1- Student createStudent();
	2- void saveStudent(Student student);
	3- Student getStudent(String line);
	4- List<Student> getStudentList();
	
	ចូរ implement interface ខាងលើ
	1- get from keyboard
	2- get that student to save in text file with format 
	  id;name;gender;grade
	3- from a string ( example: "1;Dara;M;12") convert it to object Student
	4- from a text file, please get list of students.
 */
	public static void main(String[] args) {
		// How to use interface
		// Define specification and implementation
		// Code structure
		
		StudentService studentService = new StudentServiceImpl();
		
		/*Student student = studentService.createStudent();
		System.out.println(student.toString());
		
		studentService.saveStudent(student);
		*/
		/*
		String text = "3;Veasna;M;11";
		Student st = studentService.getStudent(text);
		System.out.println(st.toString());
		*/
		List<Student> studentList = studentService.getStudentList();
		//System.out.println(studentList);
		for(Student st : studentList) {
			System.out.println(st.getName());
		}
		
	}
	
	

}
