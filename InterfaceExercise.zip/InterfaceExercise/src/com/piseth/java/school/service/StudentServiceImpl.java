package com.piseth.java.school.service;

import java.util.ArrayList;
import java.util.List;

import com.piseth.java.school.model.Student;
import com.piseth.java.school.util.FileUtil;
import com.piseth.java.school.util.InputUtil;

public class StudentServiceImpl implements StudentService{
	private static final String SEPARATOR = ";";

	@Override
	public Student createStudent() {
		int id = InputUtil.getInt("Input Id: ");
		String name = InputUtil.getString("Input name: ");
		String gender = InputUtil.getString("Input gender: ");
		int grade = InputUtil.getInt("Input Grade: ");
		
		return new Student(id, name, gender, grade);
	}

	@Override
	public void saveStudent(Student student) {
		FileUtil.saveData(student.toRowData());
	}

	@Override
	public Student getStudent(String line) {
		String[] elements = line.split(SEPARATOR);
		int id = Integer.parseInt(elements[0]);
		String name = elements[1];
		String gender = elements[2];
		int grade = Integer.parseInt(elements[3]);
		return new Student(id, name, gender, grade); 
	}

	@Override
	public List<Student> getStudentList() {
		List<Student> studentList = new ArrayList<>();
		List<String> textList = FileUtil.readData();
		for(String line : textList) {
			Student student = getStudent(line);
			studentList.add(student);
		}
		return studentList;
	}

}
