package com.piseth.java.school.service;

import java.util.List;

import com.piseth.java.school.model.Student;

public interface StudentService {
	
	Student createStudent();

	void saveStudent(Student student);

	Student getStudent(String line);

	List<Student> getStudentList();
}
