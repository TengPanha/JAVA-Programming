package com.piseth.java.school.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {
	private static final String fileName = "C:/DATA/student.txt";

	public static void saveData(String text) {
		try {
			File file = new File(fileName); // create if file not exist
			FileWriter fileWriter = new FileWriter(file, true); // true mean can append to file
			BufferedWriter bufferWriter = new BufferedWriter(fileWriter);

			bufferWriter.write(text);// text to write
			bufferWriter.newLine(); // new line
			bufferWriter.close(); // close file
			System.out.println("Save successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static List<String> readData() {
		List<String> textList = new ArrayList<>();
		File file = new File(fileName);
		FileReader fileReader;
		try {
			fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line = null;
			while (true) {
				line = bufferedReader.readLine();
				if (line == null) {
					break;
				}
				textList.add(line);
			}
			bufferedReader.close(); // close resource
		} catch (IOException e) {
			e.printStackTrace();
		}
		return textList;
	}
}
