package com.piseth.java.school.util;

import java.util.Scanner;

public class InputUtil {
	private static Scanner scanner = new Scanner(System.in);

	public static String getString(String label) {
		System.out.print(label);
		String text = scanner.next();
		return text;
	}
	
	public static int getInt(String label) {
		String text = getString(label);
		int value = Integer.parseInt(text);
		return value;
	}
}
